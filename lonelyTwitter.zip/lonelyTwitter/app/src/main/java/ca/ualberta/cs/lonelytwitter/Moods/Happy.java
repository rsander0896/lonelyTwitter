package ca.ualberta.cs.lonelytwitter.Moods;

import java.util.Date;

public class Happy extends Mood {

    Happy() {

        super.setDate(new Date());

    }

    Happy(Date date){

        super.setDate(date);

    }

    public void setMood() {
        super.setDesc("I am happy!");
    }

}
