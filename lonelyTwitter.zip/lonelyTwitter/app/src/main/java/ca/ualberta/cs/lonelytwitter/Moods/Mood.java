package ca.ualberta.cs.lonelytwitter.Moods;

import java.util.Date;

public abstract class Mood {

    private Date date;
    private String desc;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public abstract void setMood();

}
