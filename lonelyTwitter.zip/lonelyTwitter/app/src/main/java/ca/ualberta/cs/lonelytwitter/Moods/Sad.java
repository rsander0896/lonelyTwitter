package ca.ualberta.cs.lonelytwitter.Moods;

import java.util.Date;

public class Sad extends Mood {

    Sad() {

        super.setDate(new Date());

    }

    Sad(Date date){

        super.setDate(date);

    }

    public void setMood() {
        super.setDesc("I am sad...");
    }

}
