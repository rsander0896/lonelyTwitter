package ca.ualberta.cs.lonelytwitter.models;

public class Circle extends Shape {

    Circle() {
        super.setX(0);
        super.setY(0);
    }

    public void draw() {
        // Some code here
    }
}
